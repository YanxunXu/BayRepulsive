#' Inhouse
#'
#' This was generated the pure cell line expression data from one prostate cancer patient at Johns Hopkins hospital.
#' @docType data
#' @name Inhouse
#' @usage data(Inhouse)
#' @format This is a data frame with three components: (a) the pure cell line expression, (b) the sample proportion, (c) the mixed data.
#' Z: the pure cell line expression of three cancer cell lines -- naive CD4+ T cell, naive CD8+ T cell, and activated CD4+ T cell in tumor sample. Each line is for one cancer cell line. We selected top 100 differentially expressed gene.
#' W: the sample proportion. Each row is the proportion of one sample. We used this sample porportion to mix 10 mixed samples.
#' DATA: the mixed data with noise. Each line is the gene expression for one sample.
#' @examples
#' # import the data
#' data(Inhouse)
#' # get the mixed data
#' Inhouse$DATA
#' # get the gene expression level of pure cell line
#' Inhouse$Z
#' # get the proportion
#' Inhouse$W
#' # get the added noise
#' Inhouse$DATA - Inhouse$W%*%Inhouse$Z

#' @keywords datasets
NULL
